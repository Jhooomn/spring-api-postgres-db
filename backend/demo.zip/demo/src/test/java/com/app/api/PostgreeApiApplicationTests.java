package com.app.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostgreeApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
